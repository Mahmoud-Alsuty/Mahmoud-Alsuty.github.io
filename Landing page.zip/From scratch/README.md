# Landing Page project
# front-End development project 

# started from 4/7/2020 and ended at 5/7/2020

# welcome!👋

This project has been made by Dr Mahmoud Alsuty.
  
 this project has been made for just learn to make dynamic navBar and make smooth scroll events to sections of one page  with HTML ,CSS and JAVASCRIPT-Dom .
 
# I hope it works perfectly..
 
# Bye 🖐